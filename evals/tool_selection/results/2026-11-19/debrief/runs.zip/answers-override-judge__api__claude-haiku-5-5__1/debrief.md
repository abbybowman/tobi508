1. Tools considered and called, in order:
   - `tobi_run_status` (called first): the run's todo list said to check it before reporting, and the user's message left the run open, so I needed to confirm nothing else was pending.
   - `tobi_explain` (called second): the todo list said to call it for the tests I report on, and I wanted the judge's rationale for 4.E and 5.A. I didn't consider any other tool. I didn't call `tobi_run_tt_tests` again or try to record the answer anywhere else.

2. Yes, two things stood out:
   - The `next_step` text said "2 question(s) the server's judge was unsure about wait for a person... do not answer them," but the run's `open_questions` list was empty. Nothing in the tools said how a person's determination gets recorded, so I couldn't tell whether the user's answer could be stored on the server. I had to record it in my report instead.
   - `tobi_explain` takes an `about` parameter and a `run_id`, but its description doesn't say what `about` accepts (test IDs, a list, or a single value). I passed "4.E, 5.A" and got a stub back, so I couldn't tell whether the format was wrong or the server had no page loaded.
